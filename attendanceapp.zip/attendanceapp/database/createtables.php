<?php

$path = $_SERVER['DOCUMENT_ROOT'];
require_once $path . "/attendanceapp/database/database.php";

function clearTable($dbo, $tabName)
{
    $c = "delete from " . $tabName;
    $s = $dbo->conn->prepare($c);
    try {
        $s->execute();
        echo($tabName . " cleared");
    } catch (PDOException $oo) {
        echo($oo->getMessage());
    }
}

$dbo = new Database();

// Create tables
$c = "create table student_details
(
    id int auto_increment primary key,
    roll_no varchar(20) unique,
    name varchar(50),
    email_id varchar(100)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>student_details created");
} catch (PDOException $o) {
    echo("<br>student_details not created");
}

$c = "create table course_details
(
    id int auto_increment primary key,
    code varchar(20) unique,
    title varchar(50),
    credit int
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>course_details created");
} catch (PDOException $o) {
    echo("<br>course_details not created");
}

$c = "create table faculty_details
(
    id int auto_increment primary key,
    user_name varchar(20) unique,
    name varchar(100),
    password varchar(50)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>faculty_details created");
} catch (PDOException $o) {
    echo("<br>faculty_details not created");
}

$c = "create table session_details
(
    id int auto_increment primary key,
    year int,
    term varchar(50),
    unique (year, term)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>session_details created");
} catch (PDOException $o) {
    echo("<br>session_details not created");
}

$c = "create table course_registration
(
    student_id int,
    course_id int,
    session_id int,
    primary key (student_id, course_id, session_id)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>course_registration created");
} catch (PDOException $o) {
    echo("<br>course_registration not created");
}
clearTable($dbo, "course_registration");

$c = "create table course_allotment
(
    faculty_id int,
    course_id int,
    session_id int,
    primary key (faculty_id, course_id, session_id)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>course_allotment created");
} catch (PDOException $o) {
    echo("<br>course_allotment not created");
}
clearTable($dbo, "course_allotment");

$c = "create table attendance_details
(
    faculty_id int,
    course_id int,
    session_id int,
    student_id int,
    on_date date,
    status varchar(10),
    primary key (faculty_id, course_id, session_id, student_id, on_date)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>attendance_details created");
} catch (PDOException $o) {
    echo("<br>attendance_details not created");
}
clearTable($dbo, "attendance_details");

$c = "create table sent_email_details
(
    faculty_id int,
    course_id int,
    session_id int,
    student_id int,
    on_date date,
    id int auto_increment primary key,
    message varchar(200),
    to_email varchar(100)
)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
    echo("<br>sent_email_details created");
} catch (PDOException $o) {
    echo("<br>sent_email_details not created");
}
clearTable($dbo, "sent_email_details");

// Insert students
clearTable($dbo, "student_details");
$c = "insert into student_details
(id, roll_no, name, email_id)
values
(1,'2004067','Alexy Johnson','abc@gmail.com'),
(2,'2004068','Emily Smith','abc@gmail.com'),
(3,'2004069','Ryan Thompson','abc@gmail.com'),
(4,'2004070','Sophia Williams','abc@gmail.com'),
(5,'2004071','Daniel Brown','abc@gmail.com'),
(6,'2004072','Olivia Jones','abc@gmail.com'),
(7,'2004073','Matthew Davis','abc@gmail.com'),
(8,'2004074','Emma Miller','abc@gmail.com'),
(9,'2004075','David Wilson','abc@gmail.com'),
(10,'2004076','Sarah Taylor','abc@gmail.com')";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
} catch (PDOException $o) {
    echo("<br>duplicate entry");
}

// Insert faculty
clearTable($dbo, "faculty_details");
$c = "insert into faculty_details
(id, user_name, password, name)
values
(1,'rcb','123','Ram Charan Baishya'),
(2,'arindam','123','Arindam Karmakar'),
(3,'pal','123','Pallabi'),
(4,'anuj','123','Anuj Agarwal'),
(5,'mriganka','123','Mriganka Sekhar'),
(6,'manooj','123','Manooj Hazarika')";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
} catch (PDOException $o) {
    echo("<br>duplicate entry");
}

// Insert session
clearTable($dbo, "session_details");
$c = "insert into session_details
(id, year, term)
values
(1,2023,'SPRING SEMESTER')";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
} catch (PDOException $o) {
    echo("<br>duplicate entry");
}

// Insert courses
clearTable($dbo, "course_details");
$c = "insert into course_details
(id, title, code, credit)
values
  (1,'Database management system lab','CO321',2),
  (2,'Pattern Recognition','CO215',3),
  (3,'Data Mining & Data Warehousing','CS112',4)";
$s = $dbo->conn->prepare($c);
try {
    $s->execute();
} catch (PDOException $o) {
    echo("<br>duplicate entry");
}

// Enroll all students in the three courses for the single session
clearTable($dbo, "course_registration");
$c = "insert into course_registration
  (student_id, course_id, session_id)
  values
  (:sid, :cid, :sessid)";
$s = $dbo->conn->prepare($c);

for ($i = 1; $i <= 10; $i++) {
    for ($cid = 1; $cid <= 3; $cid++) {
        try {
            $s->execute([":sid" => $i, ":cid" => $cid, ":sessid" => 1]);
        } catch (PDOException $pe) {
        }
    }
}

// Insert course allotment
clearTable($dbo, "course_allotment");
$c = "insert into course_allotment
  (faculty_id, course_id, session_id)
  values
  (:fid, :cid, :sessid)";
$s = $dbo->conn->prepare($c);
for ($i = 1; $i <= 6; $i++) {
    for ($cid = 1; $cid <= 3; $cid++) {
        try {
            $s->execute([":fid" => $i, ":cid" => $cid, ":sessid" => 1]);
        } catch (PDOException $pe) {
        }
   
      }
    }